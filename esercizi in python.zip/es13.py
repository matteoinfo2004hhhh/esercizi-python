import os

def seqFibonacci(n):
    fib_seq=[0, 1] #Inizializziamo la successione di Fibonacci con i primi due numeri

    if n <= 2:
        return fib_seq[:n] #Restituiamo i primi n numeri se n <= 2

    while len(fib_seq) < n:
        next_num= fib_seq[-1] + fib_seq[-2] #Calcoliamo il prossimo numero di Fibonacci nella sequenza
        fib_seq.append(next_num)

    return fib_seq

def scriviSuFile(numeri, nome_file):
    with open(nome_file, 'w') as file:
        for numero in numeri:
            file.write(str(numero) + '\n')

def leggiDaFile(nome_file):
    numeri=[]
    if os.path.isfile(nome_file) and os.path.getsize(nome_file) > 0:
        with open(nome_file, 'r') as file:
            for riga in file:
                numero = int(riga.strip())
                numeri.append(numero)

    return numeri