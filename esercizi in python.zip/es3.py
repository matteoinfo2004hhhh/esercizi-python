# Inserire un numero intero e positivo e verificare se è un numero primo
# Controllare che in input si accetti esclusivamente un numero intero e positivo
numero=0
def seprimo(n):
  for i in range(2, int(n/2)+1):
    if n%i==0:
      print("Numero non primo")
      return
      print("Numero primo")

while True: # per ripetere il calcolo
  while True: # per validare l'input
    stringa= input("Numero (X per terminare) ")
    if stringa=="X" or stringa=="x":
      print("Ciao")
      exit()
    if stringa.isdigit() and stringa[0]!="-":
      numero= int(stringa)
      break
    else:
      print("input non valido")
    seprimo(numero)