contiCorrenti={
    '3883': 1000.0,
    '8338': 500.0,
    '3333': 0.0,
    '8888': 700.0,
    '3388': 650.0
}

numeroConto= input("Inserisci il numero di conto: ")
if numeroConto in contiCorrenti:
  saldo= contiCorrenti[numeroConto]
  print(f"Il saldo del conto {numeroConto} è di {saldo} euro")
else:
  print(f"Il conto {numeroConto} non è presente nella mappa dei conti correnti")

def genera_mazzo():
    valori=["1", "2", "3", "4", "5", "6", "7", "F", "D", "R"]
    semi=["P", "F", "Q", "C"]
    mazzo_carte=[]
    for seme in semi:
      for valore in valori:
        carta= valore+seme
        mazzo_carte.append(carta)
    return mazzo_carte
mazzo=genera_mazzo()
print(mazzo)