#Esempio di utilizzo
n=10  #Numero di numeri di Fibonacci da generare
nome_file='fibonacci.txt'

sequenza_letta=leggiDaFile(nome_file)
if not sequenza_letta:
    sequenza_fibonacci=seqFibonacci(n)
    scriviSuFile(sequenza_fibonacci, nome_file)
    sequenza_letta=sequenza_fibonacci
else:
    sequenza_letta=sequenza_letta[:n]

print("Sequenza di Fibonacci letta o generata:")
print(sequenza_letta)

def verificaMail(mail):
    #Verifica se la mail contiene un solo simbolo @ e almeno un punto dopo la @
    if mail.count('@') == 1 and '.' in mail.split('@')[-1]:
        return True
    else:
        return False
#Per esempio: esempioMail@gmail.com

def verificaPassword(password):
    #Verifica la lunghezza della password (deve essere di almeno 8 caratteri)
    if len(password) >= 8:
        #Verifica se la password contiene almeno una lettera maiuscola, una lettera minuscola e un numero.
        if any(char.isupper() for char in password) and any(char.islower() for char in password) and any(char.isdigit() for char in password):
            return True
    return False
#Per esempio: esempioPASSWORD8833

#Dizionario per le coppie mail-password
dizionario_credenziali={}

while True:
    #Chiede all'utente di inserire la mail
    mail=input("Inserisci la mail: ")

    #Verifica se la mail soddisfa i requisiti
    if verificaMail(mail):
        break
    else:
        print("La mail inserita non è valida. Riprova")

while True:
    #Chiede all'utente di inserire la password
    password=input("Inserisci la password: ")

    #Verifica se la password soddisfa i requisiti
    if verificaPassword(password):
        break
    else:
        print("La password inserita non è valida. Riprova")

#Aggiunge la coppia mail-password al dizionario
dizionario_credenziali[mail]=password

#Stampa il dizionario delle credenziali
print("Dizionario delle credenziali-->")
print(dizionario_credenziali)