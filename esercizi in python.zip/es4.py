
numero=3883
if numero % 5 == 0:
  print("numero è divisibile per 5")
else:
  print("numero non è divisibile per 5")

def areaEperimetroRect(base, altezza):
    perimetro= 2*base+2*altezza
    return perimetro
    area= base*altezza
    return area
base= input("Inserisci la base del rettangolo: ")
altezza= input("Inserisci l'altezza del rettangolo: ")

perimetro= areaEperimetroRect(base, altezza)
area= areaEperimetroRect(base, altezza)

print("Il perimetro del rettangolo è:", perimetro)
print("L'area del rettangolo è:", area)