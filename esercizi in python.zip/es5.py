
import math

#Lunghezza del lato delle figure
lato= int(input("Inserisci la lunghezza del lato: "))

#Calcola e stampa l'area e il perimetro del triangolo equilatero
area_triangolo= int((math.sqrt(3) / 4) * lato**2)
perimetro_triangolo= 3 * lato
print("Triangolo equilatero: Area=", area_triangolo, "Perimetro=", perimetro_triangolo)

#Calcola e stampa l'area e il perimetro del quadrato
area_quadrato= int(lato**2)
perimetro_quadrato= 4 * lato
print("Quadrato: Area=", area_quadrato, "Perimetro=", perimetro_quadrato)

#Calcola e stampa l'area e il perimetro del pentagono
area_pentagono= int((1/4) * math.sqrt(5 * (5 + 2*math.sqrt(5))) * lato**2)
perimetro_pentagono= 5 * lato
print("Pentagono: Area=", area_pentagono, "Perimetro=", perimetro_pentagono)

#Calcola e stampa l'area e il perimetro dell'esagono
area_esagono= int((3 * math.sqrt(3) / 2) * lato**2)
perimetro_esagono= 6 * lato
print("Esagono: Area=", area_esagono, "Perimetro=", perimetro_esagono)