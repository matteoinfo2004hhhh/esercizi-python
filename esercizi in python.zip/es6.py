import math

#Richiedi all'utente di inserire la lunghezza del lato e la figura desiderata
lato= int(input("Inserisci la lunghezza del lato: "))
figura= input("Inserisci il nome della figura (triangolo, quadrato, pentagono, esagono): ")

#Utilizza un costrutto if per gestire le diverse figure geometriche
if figura == "triangolo":
  #Calcola l'area e il perimetro del triangolo equilatero
  area= int((math.sqrt(3) / 4) * lato**2)
  perimetro= 3 * lato
elif figura == "quadrato":
  #Calcola l'area e il perimetro del quadrato
  area= int(lato**2)
  perimetro= 4 * lato
elif figura == "pentagono":
  #Calcola l'area e il perimetro del pentagono
  area= int((1/4) * math.sqrt(5 * (5 + 2*math.sqrt(5))) * lato**2)
  perimetro= 5 * lato
elif figura == "esagono":
  #Calcola l'area e il perimetro dell'esagono
  area= int((3 * math.sqrt(3) / 2) * lato**2)
  perimetro= 6 * lato
else:
  #Gestisci il caso in cui l'utente inserisce una figura non valida
  print("Figura non valida")
  area= None
  perimetro= None

#Stampa l'area e il perimetro della figura richiesta
if area is not None and perimetro is not None:
  #la funzione "capitalize()" serve per rendere maiuscola la prima lettera del nome della figura nella stampa finale
  print(figura.capitalize() + ": Area=", area, "Perimetro=", perimetro)