import matplotlib.pyplot as plt
import numpy as np

#crea un array di valori x
x= np.linspace(-20, 20, 100)

#calcola i valori y corrispondenti
y=3*x

#crea il grafico
plt.plot(x, y)

#imposta i limiti dell'asse x e y
plt.xlim(-20, 20)
plt.ylim(-20, 20)

#xpoints = np.array([0, 7])
#ypoints = np.array([0, 100])
#plt.plot(xpoints, ypoints)
plt.show()