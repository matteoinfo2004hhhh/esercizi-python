#Calcolare quadrato e cubo di un numero intero fornito in input
print("Quadrato e cubo di un numero")
numero= int(input("Numero: "))
quadrato= numero*numero;
cubo= quadrato*numero;
print("Quadrato di "+str(numero)+" = " + str(quadrato))
print("Cubo di "+str(numero)+" = " + str(cubo))

# Calcolare, usando una funzione, la somma dei primi n numeri interi
# con n fornito in input
def sommanpriminumeri(n):
  somma = 0
  for i in range(1,n+1):
    somma += i
  print('La somma dei primi ' + str(n) + ' numeri vale ' + str(somma))
num=int(input("Valore di n: "))
sommanpriminumeri(num)