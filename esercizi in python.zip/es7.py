import random

punteggio=0 #Inizializza il punteggio del giocatore a 0
num_lanci=0 #Inizializza il numero di lanci effettuati a 0

while punteggio < 50 or punteggio == 50: #Continua a lanciare i dadi finché il punteggio non raggiunge o supera 50
    dado1= random.randint(1, 6) #Lancio del primo dado
    dado2= random.randint(1, 6) #Lancio del secondo dado
    num_lanci += 1 #Aggiorna il numero di lanci effettuati
    punteggio_lancio= dado1 + dado2 #Aggiorna il punteggio con la somma dei valori dei due dadi
    if dado1 == dado2:
      punteggio_lancio*=2
    punteggio += punteggio_lancio

    print("Lancio", num_lanci, "- Risultato-->", "dado1: ", dado1, "dado2: ", dado2, "- Punteggio totale:", punteggio)

print("Il giocatore ha raggiunto il punteggio di 50 con", num_lanci, "lanci.")