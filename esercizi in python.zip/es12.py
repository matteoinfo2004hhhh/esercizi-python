import random

giocatore1=[]
giocatore2=[]
giocatore3=[]
giocatore4=[]
indiciSalvati=[]

def genera_mazzo():
    valori=["1", "2", "3", "4", "5", "6", "7", "F", "D", "R"]
    semi=["P", "F", "Q", "C"]
    mazzo_carte=[]
    for seme in semi:
      for valore in valori:
        carta= valore+seme
        mazzo_carte.append(carta)
    return mazzo_carte

def mescolamento(mazzo_carte):
    random.shuffle(mazzo_carte)
    return mazzo_carte

mazzo=genera_mazzo()
print("Mazzo di carte: ", mazzo)

mazzo_mescolato=mescolamento(mazzo)
print("Mazzo di carte mescolato: ", mazzo_mescolato)

def pesca(giocatore1, giocatore2, giocatore3, giocatore4, mazzo_mescolato):
    for i in range(1, 4):
      var= random.randint(0, 39)
      if indiciSalvati.count(var) != 0:
        while indiciSalvati.count(var) != 0:
          var= random.randint(0, 39)
      a=mazzo_mescolato[var]
      indiciSalvati.append(var)
      giocatore1.append(a)
    print("Queste sono le carte del Giocatore 1: ", giocatore1)

    for i in range(1, 4):
      var= random.randint(0, 39)
      if indiciSalvati.count(var) != 0:
        while indiciSalvati.count(var) != 0:
          var= random.randint(0, 39)
      a=mazzo_mescolato[var]
      indiciSalvati.append(var)
      giocatore2.append(a)
    print("Queste sono le carte del Giocatore 2: ", giocatore2)

    for i in range(1, 4):
      var= random.randint(0, 39)
      if indiciSalvati.count(var) != 0:
        while indiciSalvati.count(var) != 0:
          var= random.randint(0, 39)
      a=mazzo_mescolato[var]
      indiciSalvati.append(var)
      giocatore3.append(a)
    print("Queste sono le carte del Giocatore 3: ", giocatore3)

    for i in range(1, 4):
      var= random.randint(0, 39)
      if indiciSalvati.count(var) != 0:
        while indiciSalvati.count(var) != 0:
          var= random.randint(0, 39)
      a=mazzo_mescolato[var]
      indiciSalvati.append(var)
      giocatore4.append(a)
    print("Queste sono le carte del Giocatore 4: ", giocatore4)

pesca(giocatore1, giocatore2, giocatore3, giocatore4, mazzo_mescolato)